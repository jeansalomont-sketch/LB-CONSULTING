# LB Consulting — site one-page

Site vitrine + espace admin pour **LB Consulting**, agence de communication 360° basée à Abidjan (Riviera 1).

Aucune dépendance npm n’est requise pour démarrer : le serveur utilise uniquement le module `http` de Node.js (≥ 18).

## Démarrage

```bash
cd lb-consulting-site
cp .env.example .env   # optionnel, les valeurs par défaut suffisent en local
node server.js
```

- Site public : [http://localhost:3000](http://localhost:3000)
- Admin : [http://localhost:3000/admin](http://localhost:3000/admin)

Identifiants admin par défaut :

- e-mail : `larissa@lbconsultingci.com`
- mot de passe : `JLB2030`

## Modifier les identifiants admin

1. Ouvrir le fichier `.env` (à créer à partir de `.env.example` s’il n’existe pas).
2. Modifier :

```
ADMIN_EMAIL=larissa@lbconsultingci.com
ADMIN_PASSWORD=VotreNouveauMotDePasse
SESSION_SECRET=une-chaine-longue-et-aleatoire
```

3. Relancer `node server.js`.

Le mot de passe **n’est jamais exposé dans le code frontend**. Côté serveur, il est dérivé avec `scrypt` au démarrage et comparé en temps constant. Ne commitez pas le fichier `.env`.

## Où sont stockées les demandes de devis

| Élément | Emplacement |
|---|---|
| Historique consultable dans `/admin` | `data/quotes.json` |
| Copie e-mail brute (toujours écrite) | `data/outbox/<id>.eml` |
| Destinataire | `QUOTE_TO` dans `.env` (défaut : `larissa@lbconsultingci.com`) |

Chaque soumission du formulaire :

1. est validée côté client puis côté serveur ;
2. est ajoutée à `data/quotes.json` (historique) ;
3. génère un fichier `.eml` dans `data/outbox/` ;
4. tente l’envoi SMTP si `SMTP_HOST` est renseigné.

### Brancher l’e-mail (SMTP)

Dans `.env` :

```
SMTP_HOST=smtp.votre-hebergeur.com
SMTP_PORT=587
SMTP_SECURE=0
SMTP_USER=...
SMTP_PASS=...
SMTP_FROM=LB Consulting <noreply@lbconsultingci.com>
QUOTE_TO=larissa@lbconsultingci.com
```

Sans SMTP, le devis reste bien enregistré et l’admin peut le consulter. Le fichier `.eml` peut aussi être transféré manuellement.

## Structure

```
server.js              API + fichiers statiques
public/index.html      One-page
public/admin.html      Connexion + liste des devis
public/css/style.css
public/js/main.js
public/js/admin.js
public/assets/         Logo, favicon
src/db.js              Couche base de données
data/lb-consulting.db  SQLite (devis)
data/quotes.json       Import / secours JSON
data/outbox/           E-mails générés
.env.example           Modèle de configuration
```

## Base de données

Par défaut : **SQLite** intégré à Node 22+ (`node:sqlite`), fichier `data/lb-consulting.db`. Aucun `npm install`.

```
DATABASE_CLIENT=sqlite
DATABASE_PATH=data/lb-consulting.db
```

`DATABASE_CLIENT=json` conserve l’ancien fichier `data/quotes.json`.

Au premier démarrage SQLite, les devis déjà présents dans `quotes.json` sont importés automatiquement. Sauvegarder `data/lb-consulting.db` en production.

Routes API :

- `POST /api/quote` — dépôt d’un devis
- `POST /api/admin/login` — session cookie httpOnly signée
- `POST /api/admin/logout`
- `GET  /api/admin/me`
- `GET  /api/admin/quotes`
- `PATCH /api/admin/quotes/:id` — statuts `nouveau` | `lu` | `traite`

## Cache HTTP

Le serveur envoie `Cache-Control`, `ETag` et `Last-Modified`. Si le fichier n’a pas changé, le navigateur reçoit un **304**.

| Ressource | Cache-Control |
|---|---|
| HTML (`/`, `/admin`) | `public, max-age=0, must-revalidate` |
| CSS / JS (`?v=`) | `public, max-age=86400, stale-while-revalidate=604800` |
| Images / favicon | `public, max-age=2592000, immutable` |
| API `/api/*` | `no-store` |

Variables `.env` : `CACHE_ENABLED`, `CACHE_HTML_MAX_AGE`, `CACHE_CSS_MAX_AGE`, `CACHE_ASSETS_MAX_AGE`.

Après modification d’un CSS/JS, incrémenter `?v=` dans `index.html` et `admin.html`.

## Performances

- Images WebP compressées (logo nav ~3,6 Ko, visuels portfolio ~12–17 Ko)
- Lazy-load + `decoding="async"` sur le portfolio, preload du logo et du CSS
- Aucune webfont tierce (stack système) pour supprimer le waterfall Google Fonts
- Gzip + ETag + politiques de cache ci-dessus
- `content-visibility: auto` sous la ligne de flottaison
- Respect de `prefers-reduced-motion`

## Déploiement en production

Cible : VPS Ubuntu/Debian, Node 20, Nginx, systemd, Let’s Encrypt.

1. Pointer le domaine (`A` @ et www) vers l’IP du VPS, ouvrir 80/443.
2. Déposer le projet puis installer :

```bash
sudo DOMAIN=lbconsultingci.com bash deploy/install.sh
```

3. Éditer `/var/www/lb-consulting/.env` (mot de passe admin, SMTP, `PUBLIC_ORIGIN`).
4. Activer HTTPS :

```bash
sudo certbot --nginx -d lbconsultingci.com -d www.lbconsultingci.com
```

Le site est alors sur `https://lbconsultingci.com`.

```bash
sudo systemctl status lb-consulting
sudo journalctl -u lb-consulting -f
sudo bash deploy/update.sh
```

Fichiers dans `deploy/` : `install.sh`, `update.sh`, `lb-consulting.service`, `nginx-ssl.conf`, `env.production`.

## HTTPS (production)

Mode recommandé : **Nginx + Let’s Encrypt**. Node reste en HTTP sur `127.0.0.1:3000`.

```bash
sudo apt install nginx certbot python3-certbot-nginx
sudo cp deploy/nginx-ssl.conf /etc/nginx/sites-available/lb-consulting
# adapter le domaine dans le fichier
sudo ln -sf /etc/nginx/sites-available/lb-consulting /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d lbconsultingci.com -d www.lbconsultingci.com
```

`.env` :

```
PUBLIC_ORIGIN=https://lbconsultingci.com
FORCE_HTTPS=1
TRUST_PROXY=1
```

- `FORCE_HTTPS=1` : redirection 301 HTTP → HTTPS
- `TRUST_PROXY=1` : lecture de `X-Forwarded-Proto` (cookie `Secure` + HSTS)
- TLS direct Node possible via `SSL_CERT` / `SSL_KEY` / `HTTPS_PORT`

Le modèle Nginx est dans `deploy/nginx-ssl.conf`.

## Déploiement

Terminer le TLS au reverse-proxy, proxyfier vers le port `3000`. Définir `SESSION_SECRET`, `ADMIN_PASSWORD` et `PUBLIC_ORIGIN`. Sauvegarder `data/`.

Pour un hébergement PHP-only, le frontend `public/` peut être servi tel quel, mais l’admin et le stockage nécessitent Node.
