#!/usr/bin/env bash
# Installation initiale sur un VPS Ubuntu/Debian.
# Usage : sudo DOMAIN=lbconsultingci.com bash deploy/install.sh
set -euo pipefail

DOMAIN="${DOMAIN:-lbconsultingci.com}"
APP_DIR="${APP_DIR:-/var/www/lb-consulting}"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Lancer en root : sudo DOMAIN=$DOMAIN bash deploy/install.sh" >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y nginx certbot python3-certbot-nginx curl ca-certificates

if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

id www-data >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin www-data

mkdir -p "$APP_DIR" "$APP_DIR/data/outbox"
rsync -a --delete \
  --exclude node_modules \
  --exclude data/quotes.json \
  --exclude data/outbox \
  --exclude .env \
  "$SRC_DIR/" "$APP_DIR/"

if [[ ! -f "$APP_DIR/.env" ]]; then
  cp "$APP_DIR/deploy/env.production" "$APP_DIR/.env"
  sed -i "s#https://lbconsultingci.com#https://$DOMAIN#g" "$APP_DIR/.env"
  SECRET="$(head -c 48 /dev/urandom | base64 | tr -d '\n+/=' | head -c 64)"
  sed -i "s#SESSION_SECRET=.*#SESSION_SECRET=$SECRET#" "$APP_DIR/.env"
  echo "Fichier $APP_DIR/.env créé — éditez le mot de passe admin et le SMTP."
fi

chown -R www-data:www-data "$APP_DIR"
chmod 640 "$APP_DIR/.env"

sed "s/lbconsultingci.com/$DOMAIN/g" "$APP_DIR/deploy/nginx-ssl.conf" > /etc/nginx/sites-available/lb-consulting
ln -sfn /etc/nginx/sites-available/lb-consulting /etc/nginx/sites-enabled/lb-consulting
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl enable --now nginx

cp "$APP_DIR/deploy/lb-consulting.service" /etc/systemd/system/lb-consulting.service
systemctl daemon-reload
systemctl enable --now lb-consulting

echo
echo "Application lancée. Obtenir le certificat :"
echo "  sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN"
echo "Puis : https://$DOMAIN"
