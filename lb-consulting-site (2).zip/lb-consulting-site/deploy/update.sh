#!/usr/bin/env bash
# Mise à jour du code déjà installé.
# Usage : sudo bash deploy/update.sh
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/lb-consulting}"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Lancer en root : sudo bash deploy/update.sh" >&2
  exit 1
fi

rsync -a \
  --exclude node_modules \
  --exclude .env \
  --exclude data \
  "$SRC_DIR/" "$APP_DIR/"

chown -R www-data:www-data "$APP_DIR"
chmod 640 "$APP_DIR/.env" 2>/dev/null || true
systemctl restart lb-consulting
systemctl reload nginx
echo "Mise à jour terminée."
