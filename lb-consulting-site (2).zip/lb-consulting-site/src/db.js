"use strict";

const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");
const DATA_DIR = path.join(ROOT, "data");
const JSON_FILE = path.join(DATA_DIR, "quotes.json");

const CLIENT = (process.env.DATABASE_CLIENT || "sqlite").toLowerCase();
const DB_PATH = process.env.DATABASE_PATH
  || (process.env.DATABASE_URL && process.env.DATABASE_URL.startsWith("sqlite:")
    ? process.env.DATABASE_URL.replace(/^sqlite:/, "")
    : path.join(DATA_DIR, "lb-consulting.db"));

function resolvePath(p) {
  return path.isAbsolute(p) ? p : path.join(ROOT, p);
}

function rowToQuote(row) {
  if (!row) return null;
  return {
    id: row.id,
    firstname: row.firstname,
    lastname: row.lastname,
    company: row.company || "",
    email: row.email,
    phone: row.phone || "",
    service: row.service || "",
    budget: row.budget || "",
    message: row.message || "",
    status: row.status || "nouveau",
    createdAt: row.created_at,
    ip: row.ip || "",
  };
}

function createJsonStore() {
  const file = JSON_FILE;
  if (!fs.existsSync(file)) fs.writeFileSync(file, "[]");

  function read() {
    try {
      const data = JSON.parse(fs.readFileSync(file, "utf8"));
      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  }

  function write(list) {
    fs.writeFileSync(file, JSON.stringify(list, null, 2));
  }

  return {
    driver: "json",
    path: file,
    listQuotes() {
      return read();
    },
    insertQuote(item) {
      const list = read();
      list.unshift(item);
      write(list);
      return item;
    },
    updateQuoteStatus(id, status) {
      const list = read();
      const idx = list.findIndex((q) => q.id === id);
      if (idx === -1) return null;
      list[idx].status = status;
      write(list);
      return list[idx];
    },
  };
}

function createSqliteStore() {
  const { DatabaseSync } = require("node:sqlite");
  const file = resolvePath(DB_PATH);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec(`
    CREATE TABLE IF NOT EXISTS quotes (
      id TEXT PRIMARY KEY,
      firstname TEXT NOT NULL,
      lastname TEXT NOT NULL,
      company TEXT DEFAULT '',
      email TEXT NOT NULL,
      phone TEXT DEFAULT '',
      service TEXT DEFAULT '',
      budget TEXT DEFAULT '',
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'nouveau',
      created_at TEXT NOT NULL,
      ip TEXT DEFAULT '',
      updated_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_quotes_created ON quotes(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_quotes_status ON quotes(status);
  `);

  const insert = db.prepare(`
    INSERT INTO quotes (
      id, firstname, lastname, company, email, phone, service, budget,
      message, status, created_at, ip, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const selectAll = db.prepare("SELECT * FROM quotes ORDER BY created_at DESC");
  const selectOne = db.prepare("SELECT * FROM quotes WHERE id = ?");
  const updateStatus = db.prepare("UPDATE quotes SET status = ?, updated_at = ? WHERE id = ?");
  const count = db.prepare("SELECT COUNT(*) AS n FROM quotes");

  if (count.get().n === 0 && fs.existsSync(JSON_FILE)) {
    try {
      const legacy = JSON.parse(fs.readFileSync(JSON_FILE, "utf8"));
      if (Array.isArray(legacy) && legacy.length) {
        const tx = db.transaction((rows) => {
          for (const q of rows) {
            insert.run(
              q.id, q.firstname || "", q.lastname || "", q.company || "",
              q.email || "", q.phone || "", q.service || "", q.budget || "",
              q.message || "", q.status || "nouveau", q.createdAt || new Date().toISOString(),
              q.ip || "", new Date().toISOString()
            );
          }
        });
        tx(legacy);
        console.log(`Migration JSON → SQLite : ${legacy.length} devis importés.`);
      }
    } catch (err) {
      console.warn("Migration JSON ignorée :", err.message);
    }
  }

  return {
    driver: "sqlite",
    path: file,
    listQuotes() {
      return selectAll.all().map(rowToQuote);
    },
    insertQuote(item) {
      insert.run(
        item.id,
        item.firstname,
        item.lastname,
        item.company || "",
        item.email,
        item.phone || "",
        item.service || "",
        item.budget || "",
        item.message,
        item.status || "nouveau",
        item.createdAt,
        item.ip || "",
        item.createdAt
      );
      return item;
    },
    updateQuoteStatus(id, status) {
      const existing = selectOne.get(id);
      if (!existing) return null;
      updateStatus.run(status, new Date().toISOString(), id);
      return rowToQuote(selectOne.get(id));
    },
  };
}

function openDatabase() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (CLIENT === "json") return createJsonStore();
  try {
    return createSqliteStore();
  } catch (err) {
    console.warn("SQLite indisponible, fallback JSON :", err.message);
    return createJsonStore();
  }
}

module.exports = { openDatabase, JSON_FILE, DATA_DIR };
