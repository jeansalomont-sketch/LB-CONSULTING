(() => {
  const burger = document.getElementById("burger");
  const menu = document.getElementById("menu");
  if (burger && menu) {
    burger.addEventListener("click", () => {
      const open = menu.classList.toggle("is-open");
      burger.setAttribute("aria-expanded", String(open));
    });
    menu.querySelectorAll("a").forEach((a) =>
      a.addEventListener("click", () => {
        menu.classList.remove("is-open");
        burger.setAttribute("aria-expanded", "false");
      })
    );
  }

  document.querySelectorAll(".filter").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".filter").forEach((b) => b.classList.remove("is-active"));
      btn.classList.add("is-active");
      const f = btn.dataset.filter;
      document.querySelectorAll(".work").forEach((card) => {
        const cats = (card.dataset.cat || "").split(/\s+/);
        card.hidden = f !== "all" && !cats.includes(f);
      });
    });
  });

  document.querySelectorAll("[data-modal]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const el = document.getElementById(btn.dataset.modal);
      if (el) el.classList.add("is-open");
    });
  });
  document.querySelectorAll("[data-close], .modal").forEach((el) => {
    el.addEventListener("click", (e) => {
      if (e.target === el || e.target.hasAttribute("data-close")) {
        el.closest(".modal")?.classList.remove("is-open");
        if (el.classList.contains("modal")) el.classList.remove("is-open");
      }
    });
  });

  const form = document.getElementById("quote-form");
  if (!form) return;

  const toast = document.getElementById("form-toast");
  const submitBtn = document.getElementById("submit-btn");

  const rules = {
    firstname: (v) => (v.trim().length < 2 ? "Indiquez votre prénom." : ""),
    lastname: (v) => (v.trim().length < 2 ? "Indiquez votre nom." : ""),
    email: (v) => (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? "" : "E-mail invalide."),
    phone: (v) => (/^[+\d][\d\s().-]{6,24}$/.test(v) ? "" : "Téléphone invalide."),
    service: (v) => (v ? "" : "Choisissez un service."),
    message: (v) => (v.trim().length < 12 ? "Décrivez votre besoin (12 caractères min.)." : ""),
  };

  function showFieldError(name, msg) {
    const wrap = form.querySelector(`[data-field="${name}"]`);
    if (!wrap) return;
    wrap.classList.toggle("error", Boolean(msg));
    const err = wrap.querySelector(".err");
    if (err) err.textContent = msg || "";
  }

  function validate() {
    const data = Object.fromEntries(new FormData(form).entries());
    let ok = true;
    Object.keys(rules).forEach((key) => {
      const msg = rules[key](data[key] || "");
      showFieldError(key, msg);
      if (msg) ok = false;
    });
    return { ok, data };
  }

  form.querySelectorAll("input, select, textarea").forEach((el) => {
    el.addEventListener("blur", () => {
      if (rules[el.name]) showFieldError(el.name, rules[el.name](el.value || ""));
    });
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const { ok, data } = validate();
    if (!ok) {
      toast.className = "toast is-on bad";
      toast.textContent = "Merci de corriger les champs indiqués.";
      return;
    }
    submitBtn.disabled = true;
    submitBtn.textContent = "Envoi…";
    try {
      const res = await fetch("/api/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        if (json.errors) Object.entries(json.errors).forEach(([k, v]) => showFieldError(k, v));
        throw new Error(json.error || "Envoi impossible.");
      }
      toast.className = "toast is-on";
      toast.textContent = `Demande envoyée (réf. ${json.id}). Nous vous recontactons rapidement.`;
      form.reset();
    } catch (err) {
      toast.className = "toast is-on bad";
      toast.textContent = err.message || "Une erreur est survenue.";
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Envoyer la demande";
    }
  });
})();
