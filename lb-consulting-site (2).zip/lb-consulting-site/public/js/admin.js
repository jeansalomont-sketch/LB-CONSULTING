(() => {
  const loginView = document.getElementById("login-view");
  const dashView = document.getElementById("dash-view");
  const rows = document.getElementById("rows");
  const empty = document.getElementById("empty");
  const detail = document.getElementById("detail");
  const detailBox = document.getElementById("detail-box");
  const loginError = document.getElementById("login-error");

  async function api(path, opts = {}) {
    const res = await fetch(path, {
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
      ...opts,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(data.error || "Erreur");
      err.status = res.status;
      throw err;
    }
    return data;
  }

  function fmtDate(iso) {
    try {
      return new Date(iso).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" });
    } catch {
      return iso;
    }
  }

  function render(list) {
    rows.innerHTML = "";
    empty.hidden = list.length > 0;
    list.forEach((q) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${fmtDate(q.createdAt)}</td>
        <td><strong>${escapeHtml(q.firstname)} ${escapeHtml(q.lastname)}</strong><br /><span class="muted">${escapeHtml(q.company || "—")}</span></td>
        <td>${escapeHtml(q.email)}<br />${escapeHtml(q.phone)}</td>
        <td>${escapeHtml(q.service)}</td>
        <td>${escapeHtml(q.budget || "—")}</td>
        <td><span class="badge ${q.status}">${q.status}</span></td>
        <td><button class="btn btn-ghost" data-id="${q.id}" style="padding:8px 12px;color:#0b0b0b;border-color:rgba(11,11,11,.15)">Voir</button></td>`;
      rows.appendChild(tr);
    });
  }

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function openDetail(q) {
    detailBox.innerHTML = `
      <h3>${escapeHtml(q.firstname)} ${escapeHtml(q.lastname)}</h3>
      <p class="muted">${escapeHtml(q.id)} · ${fmtDate(q.createdAt)}</p>
      <p><strong>Entreprise</strong> ${escapeHtml(q.company || "—")}<br />
         <strong>E-mail</strong> <a href="mailto:${escapeHtml(q.email)}">${escapeHtml(q.email)}</a><br />
         <strong>Tél.</strong> <a href="tel:${escapeHtml(q.phone)}">${escapeHtml(q.phone)}</a><br />
         <strong>Service</strong> ${escapeHtml(q.service)}<br />
         <strong>Budget</strong> ${escapeHtml(q.budget || "Non précisé")}</p>
      <p>${escapeHtml(q.message)}</p>
      <p style="margin-top:16px;display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn-primary" data-status="lu" data-id="${q.id}">Marquer lu</button>
        <button class="btn btn-ghost" data-status="traite" data-id="${q.id}" style="color:#0b0b0b;border-color:rgba(11,11,11,.2)">Traité</button>
        <button class="btn btn-ghost" data-close style="color:#0b0b0b;border-color:rgba(11,11,11,.2)">Fermer</button>
      </p>`;
    detail.classList.add("is-open");
  }

  async function loadQuotes() {
    const data = await api("/api/admin/quotes");
    window.__quotes = data.quotes || [];
    render(window.__quotes);
  }

  async function boot() {
    try {
      const me = await api("/api/admin/me");
      loginView.hidden = true;
      dashView.hidden = false;
      document.getElementById("who").textContent = me.email;
      await loadQuotes();
    } catch {
      loginView.hidden = false;
      dashView.hidden = true;
    }
  }

  document.getElementById("login-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    loginError.style.display = "none";
    const fd = new FormData(e.target);
    try {
      await api("/api/admin/login", {
        method: "POST",
        body: JSON.stringify({ email: fd.get("email"), password: fd.get("password") }),
      });
      await boot();
    } catch (err) {
      loginError.style.display = "block";
      loginError.textContent = err.message;
    }
  });

  document.getElementById("logout").addEventListener("click", async () => {
    await api("/api/admin/logout", { method: "POST", body: "{}" });
    window.__quotes = [];
    await boot();
  });

  rows.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-id]");
    if (!btn) return;
    const q = (window.__quotes || []).find((x) => x.id === btn.dataset.id);
    if (q) openDetail(q);
  });

  detail.addEventListener("click", async (e) => {
    if (e.target === detail || e.target.hasAttribute("data-close")) detail.classList.remove("is-open");
    const st = e.target.dataset.status;
    const id = e.target.dataset.id;
    if (st && id) {
      await api(`/api/admin/quotes/${id}`, { method: "PATCH", body: JSON.stringify({ status: st }) });
      detail.classList.remove("is-open");
      await loadQuotes();
    }
  });

  boot();
})();
