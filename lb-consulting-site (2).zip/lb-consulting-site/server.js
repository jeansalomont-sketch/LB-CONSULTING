/**
 * LB Consulting — serveur HTTP sans dépendance externe.
 * Stockage des devis : SQLite (data/lb-consulting.db) ou JSON de secours
 * Sessions admin : cookie httpOnly signé
 * Mot de passe : scrypt (jamais en clair côté client)
 */
"use strict";

const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");
const net = require("net");
const tls = require("tls");
const zlib = require("zlib");

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, "data");
const OUTBOX_DIR = path.join(DATA_DIR, "outbox");

function loadEnv() {
  const envPath = path.join(ROOT, ".env");
  if (!fs.existsSync(envPath)) return;
  const raw = fs.readFileSync(envPath, "utf8");
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eq = trimmed.indexOf("=");
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    let val = trimmed.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = val;
  }
}
loadEnv();

const PORT = Number(process.env.PORT || 3000);
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "larissa@lbconsultingci.com").toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "JLB2030";
const QUOTE_TO = process.env.QUOTE_TO || "larissa@lbconsultingci.com";
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex");
const CACHE_ENABLED = process.env.CACHE_ENABLED !== "0";
const CACHE_HTML = Number(process.env.CACHE_HTML_MAX_AGE ?? 0);
const CACHE_CSS = Number(process.env.CACHE_CSS_MAX_AGE ?? 86400);
const CACHE_ASSETS = Number(process.env.CACHE_ASSETS_MAX_AGE ?? 2592000);
const HTTPS_PORT = Number(process.env.HTTPS_PORT || 443);
const SSL_CERT = process.env.SSL_CERT || "";
const SSL_KEY = process.env.SSL_KEY || "";
const SSL_CA = process.env.SSL_CA || "";
const FORCE_HTTPS = process.env.FORCE_HTTPS === "1";
const TRUST_PROXY = process.env.TRUST_PROXY !== "0";
const PUBLIC_ORIGIN = (process.env.PUBLIC_ORIGIN || "").replace(/\/$/, "");
const HSTS_MAX_AGE = Number(process.env.HSTS_MAX_AGE ?? 15552000);

const SCRYPT_SALT = Buffer.from("lb-consulting-admin-v1");
const ADMIN_HASH = crypto.scryptSync(ADMIN_PASSWORD, SCRYPT_SALT, 64);

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(OUTBOX_DIR, { recursive: true });
const { openDatabase } = require("./src/db");
const db = openDatabase();

const sessions = new Map();
const loginAttempts = new Map();

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".txt": "text/plain; charset=utf-8",
  ".xml": "application/xml; charset=utf-8",
  ".webmanifest": "application/manifest+json",
};

function send(res, status, body, headers = {}) {
  const payload = Buffer.isBuffer(body) ? body : Buffer.from(body == null ? "" : String(body));
  res.writeHead(status, {
    "Content-Length": payload.length,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "SAMEORIGIN",
    ...headers,
  });
  res.end(payload);
}

function json(res, status, data, extraHeaders = {}) {
  send(res, status, JSON.stringify(data), {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    ...extraHeaders,
  });
}

function parseCookies(req) {
  const out = {};
  const raw = req.headers.cookie;
  if (!raw) return out;
  for (const part of raw.split(";")) {
    const i = part.indexOf("=");
    if (i === -1) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function sign(value) {
  const h = crypto.createHmac("sha256", SESSION_SECRET).update(value).digest("hex");
  return `${value}.${h}`;
}

function unsign(signed) {
  if (!signed || !signed.includes(".")) return null;
  const i = signed.lastIndexOf(".");
  const value = signed.slice(0, i);
  const sig = signed.slice(i + 1);
  const expected = crypto.createHmac("sha256", SESSION_SECRET).update(value).digest("hex");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return null;
  if (!crypto.timingSafeEqual(a, b)) return null;
  return value;
}

function getSession(req) {
  const sid = unsign(parseCookies(req).lb_admin);
  if (!sid) return null;
  const s = sessions.get(sid);
  if (!s) return null;
  if (Date.now() > s.expires) {
    sessions.delete(sid);
    return null;
  }
  return s;
}

function isHttps(req) {
  if (req.socket && req.socket.encrypted) return true;
  if (!TRUST_PROXY) return false;
  const proto = String(req.headers["x-forwarded-proto"] || "").split(",")[0].trim().toLowerCase();
  return proto === "https";
}

function cookieFlags(req) {
  const secure = isHttps(req) || FORCE_HTTPS ? "; Secure" : "";
  return `HttpOnly; SameSite=Lax; Path=/; Max-Age=${60 * 60 * 8}${secure}`;
}

function setSessionCookie(resHeaders, sid, req) {
  const signed = sign(sid);
  resHeaders["Set-Cookie"] = `lb_admin=${encodeURIComponent(signed)}; ${cookieFlags(req)}`;
}

function clearSessionCookie(resHeaders, req) {
  const secure = isHttps(req) || FORCE_HTTPS ? "; Secure" : "";
  resHeaders["Set-Cookie"] = `lb_admin=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secure}`;
}

function readBody(req, limit = 200_000) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > limit) {
        reject(new Error("payload_too_large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        resolve(Object.fromEntries(new URLSearchParams(raw)));
      }
    });
    req.on("error", reject);
  });
}

function loadQuotes() {
  return db.listQuotes();
}

function sanitize(str, max = 2000) {
  return String(str || "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "")
    .trim()
    .slice(0, max);
}

function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validPhone(phone) {
  return /^[+\d][\d\s().-]{6,24}$/.test(phone);
}

function timingSafeEqualStr(a, b) {
  const ha = crypto.createHash("sha256").update(String(a)).digest();
  const hb = crypto.createHash("sha256").update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function checkPassword(plain) {
  const hash = crypto.scryptSync(String(plain), SCRYPT_SALT, 64);
  return crypto.timingSafeEqual(hash, ADMIN_HASH);
}

function tooManyLogins(ip) {
  const now = Date.now();
  const rec = loginAttempts.get(ip) || { n: 0, start: now };
  if (now - rec.start > 15 * 60 * 1000) {
    loginAttempts.set(ip, { n: 1, start: now });
    return false;
  }
  rec.n += 1;
  loginAttempts.set(ip, rec);
  return rec.n > 12;
}

function buildEmail({ firstname, lastname, company, email, phone, service, budget, message, id, createdAt }) {
  const subject = `[LB Consulting] Nouvelle demande de devis — ${firstname} ${lastname}`;
  const text = [
    "Nouvelle demande de devis reçue depuis le site lbconsulting.",
    "",
    `Référence : ${id}`,
    `Date      : ${createdAt}`,
    "",
    `Nom       : ${lastname}`,
    `Prénom    : ${firstname}`,
    `Entreprise: ${company || "—"}`,
    `E-mail    : ${email}`,
    `Téléphone : ${phone}`,
    `Service   : ${service}`,
    `Budget    : ${budget || "Non précisé"}`,
    "",
    "Description du besoin :",
    message,
    "",
    "—",
    "Cet e-mail a été généré automatiquement par le site LB Consulting.",
  ].join("\n");
  return { subject, text };
}

function writeOutbox(id, to, subject, text) {
  const eml = [
    `From: LB Consulting <noreply@lbconsultingci.com>`,
    `To: ${to}`,
    `Subject: ${subject}`,
    `Date: ${new Date().toUTCString()}`,
    "Content-Type: text/plain; charset=utf-8",
    "",
    text,
  ].join("\r\n");
  fs.writeFileSync(path.join(OUTBOX_DIR, `${id}.eml`), eml);
}

function smtpSend({ host, port, secure, user, pass, from, to, subject, text }) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error("smtp_timeout"));
      try { socket.destroy(); } catch {}
    }, 20000);

    let buffer = "";
    let step = 0;
    const commands = [];

    const onReady = () => {
      commands.push(`EHLO lbconsultingci.com`);
      if (user) {
        commands.push("AUTH LOGIN");
        commands.push(Buffer.from(user).toString("base64"));
        commands.push(Buffer.from(pass || "").toString("base64"));
      }
      commands.push(`MAIL FROM:<${from.match(/<([^>]+)>/) ? from.match(/<([^>]+)>/)[1] : from}>`);
      commands.push(`RCPT TO:<${to}>`);
      commands.push("DATA");
      step = 0;
      writeNext();
    };

    const writeNext = () => {
      if (step >= commands.length) return;
      socket.write(commands[step] + "\r\n");
      step += 1;
    };

    const handleLine = (line) => {
      const code = Number(line.slice(0, 3));
      if (step === 0 && (code === 220)) {
        onReady();
        return;
      }
      if (commands[step - 1] === "DATA" && (code === 354 || code === 250)) {
        const payload =
          `From: ${from}\r\nTo: ${to}\r\nSubject: ${subject}\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n${text}\r\n.\r\n`;
        socket.write(payload);
        socket.write("QUIT\r\n");
        clearTimeout(timeout);
        resolve(true);
        return;
      }
      if (code >= 400) {
        clearTimeout(timeout);
        reject(new Error(line));
        return;
      }
      if (step < commands.length) writeNext();
    };

    const onData = (chunk) => {
      buffer += chunk.toString("utf8");
      let idx;
      while ((idx = buffer.indexOf("\r\n")) !== -1) {
        const line = buffer.slice(0, idx);
        buffer = buffer.slice(idx + 2);
        if (/^\d{3}-/.test(line)) continue;
        handleLine(line);
      }
    };

    let socket;
    const onConnect = () => {
      socket.on("data", onData);
      socket.on("error", (err) => {
        clearTimeout(timeout);
        reject(err);
      });
    };

    if (secure) {
      socket = tls.connect({ host, port, servername: host }, onConnect);
    } else {
      socket = net.connect({ host, port }, onConnect);
    }
  });
}

async function dispatchEmail(mail) {
  writeOutbox(mail.id, QUOTE_TO, mail.subject, mail.text);
  const host = process.env.SMTP_HOST;
  if (!host) return { sent: false, reason: "smtp_not_configured" };
  try {
    await smtpSend({
      host,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === "1",
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
      from: process.env.SMTP_FROM || "LB Consulting <noreply@lbconsultingci.com>",
      to: QUOTE_TO,
      subject: mail.subject,
      text: mail.text,
    });
    return { sent: true };
  } catch (err) {
    console.error("[smtp]", err.message);
    return { sent: false, reason: err.message };
  }
}

function safeJoin(root, urlPath) {
  const decoded = decodeURIComponent(urlPath.split("?")[0]);
  const cleaned = path.normalize(decoded).replace(/^(\.\.[/\\])+/, "");
  const full = path.join(root, cleaned);
  if (!full.startsWith(root)) return null;
  return full;
}

const COMPRESSIBLE = new Set([".html", ".css", ".js", ".json", ".svg", ".txt", ".xml", ".webmanifest"]);
const staticCache = new Map();

function cacheControlFor(ext, urlPath) {
  if (!CACHE_ENABLED) return "no-store";
  if (urlPath === "/admin" || urlPath === "/admin/" || ext === ".html") {
    return CACHE_HTML > 0
      ? `public, max-age=${CACHE_HTML}, must-revalidate`
      : "public, max-age=0, must-revalidate";
  }
  if (ext === ".css" || ext === ".js") {
    return `public, max-age=${CACHE_CSS}, stale-while-revalidate=604800`;
  }
  if ([".webp", ".png", ".jpg", ".jpeg", ".svg", ".ico", ".woff2"].includes(ext)) {
    return `public, max-age=${CACHE_ASSETS}, immutable`;
  }
  if (ext === ".txt" || ext === ".xml" || ext === ".webmanifest") {
    return "public, max-age=86400";
  }
  return "public, max-age=3600";
}

function makeEtag(st) {
  return `"${st.size.toString(16)}-${Math.trunc(st.mtimeMs).toString(16)}"`;
}

function etagMatches(header, etag) {
  if (!header) return false;
  if (header.trim() === "*") return true;
  const weak = `W/${etag}`;
  return header.split(",").some((part) => {
    const tag = part.trim();
    return tag === etag || tag === weak || tag === `W/${etag}` || `W/${tag}` === etag;
  });
}

function notModifiedSince(header, mtime) {
  if (!header) return false;
  const since = Date.parse(header);
  if (Number.isNaN(since)) return false;
  return Math.trunc(mtime / 1000) <= Math.trunc(since / 1000);
}

function serveStatic(req, res, urlPath) {
  if (req.method !== "GET" && req.method !== "HEAD") {
    return send(res, 405, "Method Not Allowed", { "Content-Type": "text/plain", Allow: "GET, HEAD" });
  }

  let filePath = safeJoin(PUBLIC, urlPath);
  if (!filePath) return send(res, 403, "Forbidden", { "Content-Type": "text/plain" });

  if (urlPath === "/" || urlPath === "") filePath = path.join(PUBLIC, "index.html");
  if (urlPath === "/admin" || urlPath === "/admin/") filePath = path.join(PUBLIC, "admin.html");

  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) {
      if (!path.extname(urlPath) && urlPath !== "/admin" && fs.existsSync(path.join(PUBLIC, "index.html"))) {
        filePath = path.join(PUBLIC, "index.html");
      } else {
        return send(res, 404, "Not found", { "Content-Type": "text/plain" });
      }
    }

    fs.stat(filePath, (err2, stat) => {
      if (err2 || !stat.isFile()) return send(res, 404, "Not found", { "Content-Type": "text/plain" });

      const ext = path.extname(filePath).toLowerCase();
      const type = MIME[ext] || "application/octet-stream";
      const etag = makeEtag(stat);
      const lastMod = new Date(stat.mtimeMs).toUTCString();
      const cache = cacheControlFor(ext, urlPath);
      const condHeaders = {
        ETag: etag,
        "Last-Modified": lastMod,
        "Cache-Control": cache,
        Vary: "Accept-Encoding",
      };

      const inm = req.headers["if-none-match"];
      const ims = req.headers["if-modified-since"];
      if ((inm && etagMatches(inm, etag)) || (!inm && notModifiedSince(ims, stat.mtimeMs))) {
        res.writeHead(304, condHeaders);
        return res.end();
      }

      const wantGzip = COMPRESSIBLE.has(ext) && /\bgzip\b/.test(req.headers["accept-encoding"] || "");
      const cacheKey = `${filePath}|${stat.mtimeMs}|${wantGzip ? "gz" : "raw"}`;
      const finish = (buf, encoding) => {
        const headers = { "Content-Type": type, ...condHeaders };
        if (encoding) headers["Content-Encoding"] = encoding;
        if (req.method === "HEAD") {
          res.writeHead(200, { ...headers, "Content-Length": buf.length });
          return res.end();
        }
        send(res, 200, buf, headers);
      };

      const hit = staticCache.get(cacheKey);
      if (hit) return finish(hit.body, hit.encoding);

      fs.readFile(filePath, (e3, raw) => {
        if (e3) return send(res, 500, "Error", { "Content-Type": "text/plain" });
        if (wantGzip && raw.length > 256) {
          zlib.gzip(raw, { level: 6 }, (e4, gz) => {
            if (e4) return finish(raw, null);
            staticCache.set(cacheKey, { body: gz, encoding: "gzip" });
            finish(gz, "gzip");
          });
        } else {
          staticCache.set(cacheKey, { body: raw, encoding: null });
          finish(raw, null);
        }
      });
    });
  });
}

async function handleApi(req, res, url) {
  const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").toString().split(",")[0].trim();

  if (req.method === "GET" && url.pathname === "/api/health") {
    return json(res, 200, {
      ok: true,
      db: db.driver,
      uptime: Math.round(process.uptime()),
    });
  }

  if (req.method === "POST" && url.pathname === "/api/quote") {
    let body;
    try {
      body = await readBody(req);
    } catch {
      return json(res, 413, { ok: false, error: "Requête trop volumineuse." });
    }
    const firstname = sanitize(body.firstname || body.prenom, 80);
    const lastname = sanitize(body.lastname || body.nom, 80);
    const company = sanitize(body.company || body.entreprise, 120);
    const email = sanitize(body.email, 120).toLowerCase();
    const phone = sanitize(body.phone || body.telephone, 40);
    const service = sanitize(body.service, 80);
    const budget = sanitize(body.budget, 80);
    const message = sanitize(body.message || body.description, 4000);

    const errors = {};
    if (firstname.length < 2) errors.firstname = "Indiquez votre prénom.";
    if (lastname.length < 2) errors.lastname = "Indiquez votre nom.";
    if (!validEmail(email)) errors.email = "E-mail invalide.";
    if (!validPhone(phone)) errors.phone = "Téléphone invalide.";
    if (!service) errors.service = "Choisissez un service.";
    if (message.length < 12) errors.message = "Décrivez votre besoin (12 caractères minimum).";

    if (Object.keys(errors).length) return json(res, 400, { ok: false, errors });

    const item = {
      id: `LB-${Date.now().toString(36).toUpperCase()}`,
      firstname,
      lastname,
      company,
      email,
      phone,
      service,
      budget,
      message,
      status: "nouveau",
      createdAt: new Date().toISOString(),
      ip,
    };

    db.insertQuote(item);

    const mail = { id: item.id, ...buildEmail(item) };
    const emailResult = await dispatchEmail({ ...mail, id: item.id });

    return json(res, 201, {
      ok: true,
      id: item.id,
      emailed: emailResult.sent,
    });
  }

  if (req.method === "POST" && url.pathname === "/api/admin/login") {
    if (tooManyLogins(ip)) return json(res, 429, { ok: false, error: "Trop de tentatives. Réessayez plus tard." });
    let body;
    try {
      body = await readBody(req);
    } catch {
      return json(res, 413, { ok: false, error: "Requête trop volumineuse." });
    }
    const email = sanitize(body.email, 120).toLowerCase();
    const password = String(body.password || "");

    const emailOk = timingSafeEqualStr(email, ADMIN_EMAIL);
    const passOk = checkPassword(password);

    if (!emailOk || !passOk) {
      return json(res, 401, { ok: false, error: "Identifiants incorrects." });
    }

    const sid = crypto.randomBytes(24).toString("hex");
    sessions.set(sid, { email: ADMIN_EMAIL, expires: Date.now() + 8 * 60 * 60 * 1000 });
    const headers = {};
    setSessionCookie(headers, sid, req);
    return json(res, 200, { ok: true }, headers);
  }

  if (req.method === "POST" && url.pathname === "/api/admin/logout") {
    const s = getSession(req);
    const cookies = parseCookies(req);
    const sid = unsign(cookies.lb_admin);
    if (sid) sessions.delete(sid);
    const headers = {};
    clearSessionCookie(headers, req);
    return json(res, 200, { ok: true }, headers);
  }

  if (req.method === "GET" && url.pathname === "/api/admin/me") {
    const s = getSession(req);
    if (!s) return json(res, 401, { ok: false });
    return json(res, 200, { ok: true, email: s.email });
  }

  if (req.method === "GET" && url.pathname === "/api/admin/quotes") {
    const s = getSession(req);
    if (!s) return json(res, 401, { ok: false, error: "Non authentifié." });
    return json(res, 200, { ok: true, quotes: loadQuotes() });
  }

  if (req.method === "PATCH" && url.pathname.startsWith("/api/admin/quotes/")) {
    const s = getSession(req);
    if (!s) return json(res, 401, { ok: false, error: "Non authentifié." });
    const id = decodeURIComponent(url.pathname.split("/").pop());
    let body;
    try {
      body = await readBody(req);
    } catch {
      return json(res, 413, { ok: false });
    }
    const allowed = ["nouveau", "lu", "traite"];
    if (!body.status || !allowed.includes(body.status)) {
      return json(res, 400, { ok: false, error: "Statut invalide." });
    }
    const quote = db.updateQuoteStatus(id, body.status);
    if (!quote) return json(res, 404, { ok: false, error: "Introuvable." });
    return json(res, 200, { ok: true, quote });
  }

  return json(res, 404, { ok: false, error: "Route inconnue." });
}

function publicHost(req) {
  if (PUBLIC_ORIGIN) {
    try { return new URL(PUBLIC_ORIGIN).host; } catch { /* ignore */ }
  }
  return req.headers["x-forwarded-host"] || req.headers.host || "localhost";
}

function applySecurityHeaders(req, res) {
  const original = res.writeHead.bind(res);
  res.writeHead = function patchedWriteHead(status, headers) {
    const next = headers && !Array.isArray(headers) && typeof headers === "object" ? { ...headers } : {};
    if (arguments.length === 3 && typeof arguments[1] === "string") {
      return original.apply(res, arguments);
    }
    if (isHttps(req) && HSTS_MAX_AGE > 0) {
      next["Strict-Transport-Security"] = `max-age=${HSTS_MAX_AGE}; includeSubDomains`;
    }
    next["X-Content-Type-Options"] = next["X-Content-Type-Options"] || "nosniff";
    if (typeof status === "object") return original.call(res, status);
    return original.call(res, status, next);
  };
}

async function handleRequest(req, res) {
  applySecurityHeaders(req, res);
  const host = publicHost(req);
  const url = new URL(req.url, `${isHttps(req) ? "https" : "http"}://${host}`);

  if (FORCE_HTTPS && !isHttps(req) && req.method === "GET") {
    const dest = `${PUBLIC_ORIGIN || `https://${host}`}${url.pathname}${url.search}`;
    res.writeHead(301, { Location: dest, "Cache-Control": "no-store" });
    return res.end();
  }

  if (url.pathname.startsWith("/api/")) {
    return handleApi(req, res, url);
  }
  return serveStatic(req, res, url.pathname);
}

const server = http.createServer((req, res) => {
  handleRequest(req, res).catch((err) => {
    console.error(err);
    if (!res.headersSent) json(res, 500, { ok: false, error: "Erreur serveur." });
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`LB Consulting HTTP on http://localhost:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin`);
  console.log(`Base de données : ${db.driver} (${db.path})`);
});

if (SSL_CERT && SSL_KEY && fs.existsSync(SSL_CERT) && fs.existsSync(SSL_KEY)) {
  const tlsOptions = {
    cert: fs.readFileSync(SSL_CERT),
    key: fs.readFileSync(SSL_KEY),
  };
  if (SSL_CA && fs.existsSync(SSL_CA)) tlsOptions.ca = fs.readFileSync(SSL_CA);
  https.createServer(tlsOptions, (req, res) => {
    handleRequest(req, res).catch((err) => {
      console.error(err);
      if (!res.headersSent) json(res, 500, { ok: false, error: "Erreur serveur." });
    });
  }).listen(HTTPS_PORT, "0.0.0.0", () => {
    console.log(`LB Consulting HTTPS on port ${HTTPS_PORT}`);
  });
} else if (SSL_CERT || SSL_KEY) {
  console.warn("HTTPS ignoré : SSL_CERT / SSL_KEY introuvable. Placez les certificats ou utilisez Nginx.");
}
